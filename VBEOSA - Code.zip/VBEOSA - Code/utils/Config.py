# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 08:07:04 2022

@author: Oyelade
"""
import numpy as np
#Number of iterations
MaxIter = 50

#Initialization of accumulative list storage for fit and cost values
method_fit_pop=None
method_cost_pop=None

#Number of runnings for each experimentation of the algorithms
number_of_runs=1

#Variouse population sizes you want to investigate with
#p_size = [25, 50, 75, 100] #25, 50, 75, 100, 
#p_size = np.arange(25, 2525, 25)
#p_size=[25,50]


#p_size = [25, 30, 35, 40, 45, 50, 55, 60, 65, 70,
 #         75, 80, 85, 90, 95, 100, 105, 110, 115, 120,
  #        125, 130, 135, 140, 145]
#p_size = [25, 30, 35, 40, 45, 50, 55, 60, 65, 70,
 #
#         75, 80, 85, 90, 95, 100, 105, 110, 115, 120,
 #         125, 130, 135, 140, 145, 150, 155, 160, 165, 170,
  #        175, 180, 185, 190, 195, 200, 205, 210, 215, 220,
   #       225, 230, 235, 240, 245, 250, 255, 260, 265, 270,
    #      275, 280, 285, 290, 295, 300, 305, 310, 315, 320,
     #     325, 330, 335, 340, 345, 350, 355, 360, 365, 370,
      #   375, 380, 385, 390, 395]


p_size = [25, 30, 35, 40, 45, 50, 55, 60, 65, 70,
          75, 80, 85, 90, 95, 100, 105, 110, 115, 120,
          125, 130, 135, 140, 145, 150, 155, 160, 165, 170,
          175, 180, 185, 190, 195, 200, 205, 210, 215, 220,
          225, 230, 235, 240, 245, 250, 255, 260, 265, 270]
          
#p_size = [25, 30, 35, 40, 45, 50, 55, 60, 65, 70,
 #         75, 80, 85, 90, 95, 100, 105, 110, 115, 120,
  #        125, 130, 135, 140, 145, 150, 155, 160, 165, 170,
   #       175, 180, 185, 190, 195, 200, 205, 210, 215, 220,
    #      225, 230, 235, 240, 245, 250, 255, 260, 265, 270,
     #     275, 280, 285, 290, 295, 300, 305, 310, 315, 320,
      #    325, 330, 335, 340, 345, 350, 355, 360, 365, 370,
       #   375, 380, 385, 390, 395, 400, 405, 410, 415, 420,
        #  425, 430, 435, 440, 445, 450, 455, 460, 465, 470,
         #475, 480, 485, 490, 495, 500, 505, 510, 515, 520]
                                                     ###
#Store results dir
result_dir='./results/'
#D:\Ph.D\PhD\My Paper\Paper3\feature selection\BEOSA\Datasets
dataset_dir='D:/Ph.D/PhD/My Paper/Paper 4/VBEOSA/Datasets/'
runs_dir='runs/'
bests_dir='bests/'
accuracy_dir='accuracy/'
fitness_dir='fitness/'
cost_dir='cost/'
metrics_dir='metrics/'
popsize_accuracy_dir='popsizeacc/'

#Classifiers
classifiers=['knn', 'rf', 'mlp', 'dt', 'svm', 'gnb','Voting']
#All datasets to be used for experimentation
    
#All algorithms to be experimented with
algorithms=[
            #'BSFO', #'BSNDO', 
            'BEOSA', #'BIEOSA', 'BDMO', 'BSNDO',
           #'BWOA', #'BPSO', #'BGWO', #'BSFO'
        ]

datasetlist = [ 
    
                #"Lung_Cancer.csv"
                "BRCA Dataset.csv"
                #'iris.csv' #(BSFO, BSNDO)
                #'Lung.csv' (BSFO)
                #'Prostrate.csv' (BWOA, BPSO[3], BSFO, BGWO)
                #'Colon.csv' (BFSO)
                #'Leukemia.csv' (BSFO)
    
                #"BreastEW.csv", 
                #"BreastCancer.csv",
                #"CongressEW.csv", 
                #"Exactly.csv", 
                #"Exactly2.csv", 
                #"HeartEW.csv", 
    
                #^^^^"Ionosphere.csv",
                #^^^^"M-of-n.csv", 
                #"PenglungEW.csv", #(BPSO[100])
                #^^^^"Sonar.csv",
                #^^^^"SpectEW.csv", 
                #^^^^"Tic-tac-toe.csv", 
                #^^^^"Lymphography.csv", 
                
                #^^^^"Vote.csv", 
                #^^^^"Wine.csv", 
                #"Zoo.csv", #^^^^
                #"KrVsKpEW.csv", #BSFO([75, 100])
                #"WaveformEW.csv" #BGWO (3), BIEOSA (3), BSNDO,BPSO,BWOA,BSFO
              ]
    